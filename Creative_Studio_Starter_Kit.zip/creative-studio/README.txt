CREATIVE STUDIO — QUICK START

1. Open index.html in a browser to preview the website.
2. Replace the placeholder WhatsApp number 91XXXXXXXXXX with your own number:
   - Open index.html in a text editor (Notepad or VS Code).
   - Find: https://wa.me/91XXXXXXXXXX
   - Replace 91XXXXXXXXXX with your WhatsApp number including country code, digits only.
   Example format for India: 919876543210
3. Replace the sample concept gallery with your own original designs before advertising them as portfolio projects.
4. Update prices, business description and contact details as needed.

FREE PUBLISHING OPTION — GITHUB PAGES
1. Create a free account at https://github.com/
2. Create a new public repository named creative-studio.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. GitHub will provide a public website address after deployment.

Alternative: use Netlify's free plan by uploading the folder containing index.html using its manual deploy option. Check current free-plan limits before publishing.

No paid domain or hosting is required for the starter site. A custom domain is optional and usually costs money.
